`timescale 1ns/1ps

module tb_top;
    reg clk;
    reg rst;
    reg tick;
    reg [3:0] start_value;
    reg start_valid;
    wire [3:0] display_value;
    wire busy;

    //we use the FSM counter to instantiate
    fsm_counter uut (
        .clk(clk),
        .rst(rst),
        .tick(tick),
        .start_value(start_value),
        .start_valid(start_valid),
        .display_value(display_value),
        .busy(busy)
    );

    //generation of clock
    initial begin //this is where we generate the clock
        clk = 0;
        forever #5 clk = ~clk; //keeping a 10ns period
    end

    //generation of 1 sec ticks
    initial begin
        tick = 0;
        forever begin
            #50 tick = 1; // 1 sec
            #10 tick = 0;
        end
    end
    initial begin
        //Initial IDLE STATE
        rst = 1; //Reset is pressed to ensure we are in our idle state
        start_valid = 0;
        start_value = 0;
        #20;
        rst = 0;
        
        #20;//IF SWITCH 8 IS PRESSED
        start_value = 4'd8;
        start_valid = 1; //need to tell if we have pressed the switch or not
        #10;
        start_valid = 0;
        #1000; //full countdown time
        
        start_value = 4'd5;
        start_valid = 1;
        #10;
        start_valid = 0;
        #100;
        rst = 1; //during the cntdwn reset
        #20;
        rst = 0;
        #200;
        $stop;
    end
    //show values
    always @(posedge tick) begin
        if (busy)
            $display("Time %t : Display = %d", $time, display_value);
    end
endmodule