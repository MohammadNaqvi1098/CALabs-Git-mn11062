module top(
    input clk,
    input rst_btn,
    input [15:0] sw,
    output [6:0] seg,
    output [3:0] an
);

    // Internal wires
    wire rst;
    wire tick;
    wire [3:0] start_value;
    wire start_valid;
    wire [3:0] display_value;
    wire busy;
    wire [31:0] dummy_read;

    // --------------------------------------------------
    // Push-button debouncer
    // --------------------------------------------------
    debouncer db (
        .clk   (clk),
        .pbin  (rst_btn),
        .pbout (rst)
    );

    // --------------------------------------------------
    // 16-bit switch priority encoder
    // Highest switch number has priority
    // --------------------------------------------------
    priority_encoder pe (
        .sw    (sw),
        .value (start_value),
        .valid (start_valid)
    );

    // --------------------------------------------------
    // 1-second tick generator
    // --------------------------------------------------
    clock_divider cd (
        .clk  (clk),
        .rst  (rst),
        .tick (tick)
    );

    // --------------------------------------------------
    // Countdown FSM
    // --------------------------------------------------
    fsm_counter fsm (
        .clk           (clk),
        .rst           (rst),
        .tick          (tick),
        .start_value   (start_value),
        .start_valid   (start_valid),
        .display_value (display_value),
        .busy          (busy)
    );

    // --------------------------------------------------
    // Seven-segment display interface
    // --------------------------------------------------
    leds led_interface (
        .clk           (clk),
        .rst           (rst),
        .btns          (16'b0),
        .writeData     (32'b0),
        .writeEnable   (1'b0),
        .readEnable    (1'b1),
        .memAddress    (30'b0),
        .display_value (display_value),
        .readData      (dummy_read),
        .seg           (seg),
        .an            (an)
    );

endmodule