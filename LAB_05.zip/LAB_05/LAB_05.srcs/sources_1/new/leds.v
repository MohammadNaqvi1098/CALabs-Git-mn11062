module leds(
    input clk,
    input rst,
    input [15:0] btns,
    input [31:0] writeData,
    input writeEnable,
    input readEnable,
    input [29:0] memAddress,
    input [3:0] display_value, //read the current value from FSM
    output reg [31:0] readData,
    output [6:0] seg,
    output [3:0] an
);

always @(posedge clk or posedge rst) begin
    if (rst)
        readData <= 0;
    else if (readEnable)
        readData <= {28'b0, display_value};
    else
        readData <= 0;
end

sevenseg_decode ssd( //seven segment decoder initialized
    .bin(display_value),
    .seg(seg)
);
//we are using only the first segment
assign an = 4'b1110;
endmodule
