module clock_divider(
    input clk,
    input rst,
    output reg tick
);

reg [26:0] count;

always @(posedge clk or posedge rst) begin
    if (rst) begin
        count <= 0;
        tick <= 0;
    end
    else if (count == 100_000_000 - 1) begin
        count <= 0;
        tick <= 1;
    end
    else begin
        count <= count + 1;
        tick <= 0;
    end
end

endmodule