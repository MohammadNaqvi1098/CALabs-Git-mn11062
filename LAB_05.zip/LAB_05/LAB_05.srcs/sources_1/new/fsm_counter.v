module fsm_counter(
    input clk,
    input rst,
    input tick,
    input [3:0] start_value, //starting value to display
    input start_valid,
    output reg [3:0] display_value, //displaying current value on the seven seg
    output reg busy //if its counting dwn, we need to know that
);

localparam IDLE  = 2'b00; //IDLE STATE 00
localparam WAIT1 = 2'b01; //wait a second before counting down
localparam COUNT = 2'b10;

reg [1:0] state;
reg [3:0] counter;
reg start_valid_d;

always @(posedge clk or posedge rst) begin
    if (rst)
        start_valid_d <= 0;
    else
        start_valid_d <= start_valid;
end

wire start_pulse = start_valid & ~start_valid_d;

always @(posedge clk or posedge rst) begin
    if (rst) begin
        state <= IDLE;
        counter <= 0;
        display_value <= 0;
        busy <= 0;
    end
    else begin
        case (state)
            IDLE: begin
                busy <= 0;
                if (start_pulse) begin
                    counter <= start_value;
                    display_value <= start_value;
                    busy <= 1;
                    state <= WAIT1; //waiting for one full tick
                end
            end

            WAIT1: begin
                busy <= 1;
                if (tick)
                    state <= COUNT; //go to the next number after 1 sec
            end

            COUNT: begin
                busy <= 1;
                if (tick) begin
                    if (counter > 0) begin
                        counter <= counter - 1;
                        display_value <= counter - 1;
                    end
                    else begin
                        state <= IDLE;
                        busy <= 0;
                    end
                end
            end

        endcase
    end
end

endmodule
