module priority_encoder(
    input [15:0] sw,
    output reg [3:0] value,
    output reg valid
);

integer i;

always @(*) begin
    value = 0;
    valid = 0;

    for (i = 15; i >= 0; i = i - 1) begin
        if (sw[i]) begin
            value = i[3:0];
            valid = 1;
        end
    end
end

endmodule
